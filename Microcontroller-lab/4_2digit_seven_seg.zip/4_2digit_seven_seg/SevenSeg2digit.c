//char seg[]={0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80,0x90};
//int i=0;
//void main() {
//     trisb=0x00;
//     trisc=0b11000000;
//     portb=0x00;
//     portc=0x00;
//     while(1){
//         portc.f0=1;
//         portb=seg[i/10];
//         delay_ms(10);
//         portc.f0=0;
//         portc.f1=1;
//         portb=seg[i%10];
//         delay_ms(10);
//         portc.f1=0;
//       if(portc.f6==1){
//          i++;
//          while(portc.f6==1);
//       }
//       if(portc.f7==1){
//         i--;
//         while(portc.f7==1);
//       }
//       if(i<0)i=99;
//       if(i>99)i=0;
//     }
//}

//common anode
char seg[]={0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80,0x90};
int i=0;
void main(){
trisb=0x00;
trisc=0b11000000;
portb=0x00;
portc=0x00;
while(1){
  portc.f0=1;
  portb=seg[i/10];
  delay_ms(10);
  portc.f0=0;
  portc.f1=1;
  portb=seg[i%10];
  delay_ms(10);
  portc.f1=0;
  if(portc.f6==1){
  i++;
  while(portc.f6);
  }
  if(portc.f7==1){
  i--;
  while(portc.f7);
  }
  if(i>99)i=0;
  if(i<0)i=99;
}
}

//common cathod

//char seg[]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};
//int i=0;
//void main(){
//trisb=0x00;
//trisc=0b11000000;
//portb=0x00;
//portc=0x00;
//while(1){
//  portc.f0=0;
//  portb=seg[i/10];
//  delay_ms(10);
//  portc.f0=1;
//  portc.f1=0;
//  portb=seg[i%10];
//  delay_ms(10);
//  portc.f1=1;
//  if(portc.f6==1){
//    i++;
//  while(portc.f6);
//  }
//  if(portc.f7==1){
//    i--;
//  while(portc.f7);
//  }
//  if(i>99)i=0;
//  if(i<0)i=99;
//}
//}








