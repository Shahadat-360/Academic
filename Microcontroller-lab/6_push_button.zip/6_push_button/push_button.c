void main() {
    trisb=0x00;
    trisc=0xff;
    portc=0x00;
    portb=0x00;
    while(1){
    if(portc.f2==1)portb.f0=1;
    else portb.f0=0;
    }
}